import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFF004455);
const kPrimaryLightColor = Color(0xFF06767B);
